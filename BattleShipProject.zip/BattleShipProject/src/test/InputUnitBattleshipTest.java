package test;

import game.api.GameState;
import game.api.GameStateBattleship;
import game.io.InputListener;
import game.io.InputUnitBattleship;
import graphicaluserinterface.GameGUI;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;

public class InputUnitBattleshipTest {
	InputUnitBattleship input;
	GameState state;
	InputListener listener;
	GameGUI gui;

	@Before
	public void setUp() throws Exception {
		GameStateBattleship gamestate = mock(GameStateBattleship.class);
		gui = mock(GameGUI.class);
		state = gamestate;
		listener = gamestate;
		input = new InputUnitBattleship(gui, listener);
	}

	@Test
	public void test() {
		input.setup(state);

	}

}
